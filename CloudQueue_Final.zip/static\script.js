async function submitJob() {

    const name =
        document.getElementById("jobName").value.trim();

    const type =
        document.getElementById("workloadType").value;


    if (!name) {

        alert("Please enter a workload name");

        return;
    }


    const response = await fetch("/submit", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            job_name: name,

            workload_type: type

        })

    });


    const data = await response.json();


    alert(
        "Job submitted successfully!\n" +
        "Job ID: " +
        data.job_id
    );


    document.getElementById("jobName").value = "";

    refreshDashboard();
}


async function loadJobs() {

    const response = await fetch("/jobs");

    const jobs = await response.json();

    const container =
        document.getElementById("jobs");


    if (jobs.length === 0) {

        container.innerHTML =
            "<p>No workloads submitted yet.</p>";

        return;
    }


    container.innerHTML = jobs.map(job => `

        <div class="job">

            <strong>
                #${job.id} - ${job.job_name}
            </strong>

            <br>

            Workload:
            ${job.workload_type}

            <br>

            Status:
            <strong>${job.status}</strong>

            <br>

            Processing Time:
            ${job.processing_time ?? "-"} seconds

        </div>

    `).join("");
}


async function loadStats() {

    const response = await fetch("/stats");

    const data = await response.json();


    document.getElementById("total").innerText =
        data.total;

    document.getElementById("completed").innerText =
        data.completed;

    document.getElementById("queued").innerText =
        data.queued;

    document.getElementById("avgTime").innerText =
        data.avg_time + " s";
}


async function refreshDashboard() {

    await loadStats();

    await loadJobs();

}


refreshDashboard();

setInterval(refreshDashboard, 5000);