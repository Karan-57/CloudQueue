from flask import Flask, request, jsonify, render_template
import sqlite3
import time

app = Flask(__name__)

DB = "database/cloudqueue.db"


def get_db():
    return sqlite3.connect(DB)


def init_db():

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_name TEXT NOT NULL,
            workload_type TEXT NOT NULL,
            status TEXT NOT NULL,
            submitted_at REAL,
            started_at REAL,
            completed_at REAL,
            processing_time REAL
        )
    """)

    conn.commit()
    conn.close()


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/submit", methods=["POST"])
def submit_job():

    data = request.get_json() or {}

    job_name = data.get("job_name", "Test Job").strip()
    workload_type = data.get("workload_type", "CPU")

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO jobs
        (job_name, workload_type, status, submitted_at)
        VALUES (?, ?, ?, ?)
    """, (
        job_name,
        workload_type,
        "Queued",
        time.time()
    ))

    conn.commit()

    job_id = cursor.lastrowid

    conn.close()

    return jsonify({
        "message": "Job submitted successfully",
        "job_id": job_id,
        "status": "Queued"
    })


@app.route("/jobs")
def get_jobs():

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, job_name, workload_type,
               status, submitted_at, processing_time
        FROM jobs
        ORDER BY id DESC
    """)

    rows = cursor.fetchall()

    conn.close()

    jobs = []

    for row in rows:

        jobs.append({
            "id": row[0],
            "job_name": row[1],
            "workload_type": row[2],
            "status": row[3],
            "submitted_at": row[4],
            "processing_time": row[5]
        })

    return jsonify(jobs)


@app.route("/stats")
def stats():

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM jobs")
    total = cursor.fetchone()[0]

    cursor.execute("""
        SELECT COUNT(*)
        FROM jobs
        WHERE status = 'Completed'
    """)

    completed = cursor.fetchone()[0]

    cursor.execute("""
        SELECT COUNT(*)
        FROM jobs
        WHERE status = 'Queued'
    """)

    queued = cursor.fetchone()[0]

    cursor.execute("""
        SELECT COUNT(*)
        FROM jobs
        WHERE status = 'Processing'
    """)

    processing = cursor.fetchone()[0]

    cursor.execute("""
        SELECT AVG(processing_time)
        FROM jobs
        WHERE processing_time IS NOT NULL
    """)

    avg_time = cursor.fetchone()[0]

    conn.close()

    return jsonify({
        "total": total,
        "completed": completed,
        "queued": queued,
        "processing": processing,
        "avg_time": round(avg_time, 3) if avg_time else 0
    })


@app.route("/comparison")
def comparison():

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT workload_type,
               COUNT(*),
               AVG(processing_time)
        FROM jobs
        WHERE status = 'Completed'
        GROUP BY workload_type
    """)

    rows = cursor.fetchall()

    conn.close()

    result = []

    for row in rows:

        result.append({
            "workload_type": row[0],
            "jobs": row[1],
            "average_time": round(row[2], 3)
        })

    return jsonify(result)


if __name__ == "__main__":

    init_db()

    app.run(debug=True)