import sqlite3
import time

DB = "database/cloudqueue.db"


def process_jobs():

    conn = sqlite3.connect(DB)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, job_name, workload_type
        FROM jobs
        WHERE status = 'Queued'
        ORDER BY id
    """)

    jobs = cursor.fetchall()

    for job_id, job_name, workload_type in jobs:

        print()
        print("=" * 40)
        print(f"Job ID       : {job_id}")
        print(f"Job Name     : {job_name}")
        print(f"Workload     : {workload_type}")
        print("Status       : Processing")
        print("=" * 40)

        start_time = time.time()

        cursor.execute("""
            UPDATE jobs
            SET status = 'Processing',
                started_at = ?
            WHERE id = ?
        """, (start_time, job_id))

        conn.commit()

        # Simulate different workloads
        if workload_type == "CPU":
            total = 0
            for i in range(1, 1000000):
                total += i * i

        elif workload_type == "DATA":
            data = [i for i in range(100000)]
            data.sort()

        elif workload_type == "TEXT":
            text = "CloudQueue workload processing " * 10000
            text = text.lower()
            text = text.upper()

        else:
            time.sleep(2)

        end_time = time.time()

        processing_time = round(
            end_time - start_time,
            3
        )

        cursor.execute("""
            UPDATE jobs
            SET status = 'Completed',
                completed_at = ?,
                processing_time = ?
            WHERE id = ?
        """, (
            end_time,
            processing_time,
            job_id
        ))

        conn.commit()

        print(f"Status       : Completed")
        print(f"Processing   : {processing_time} seconds")

    conn.close()


if __name__ == "__main__":

    process_jobs()

    print()
    print("All queued jobs processed.")